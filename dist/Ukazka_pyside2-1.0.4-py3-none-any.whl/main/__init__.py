__all__ = ["spustit_okno"]
