import spustit_okno

if __name__ == '__main__':
    spustit_okno.main()
